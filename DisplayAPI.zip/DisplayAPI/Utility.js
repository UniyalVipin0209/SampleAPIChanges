const ReturnSampleEndPoint = () => {
  const key = "6oZAdNZcdtwAeLWAP4yG";
  let endPoint = "https://api.coinmetrics.io/v4/blockchain/btc/accounts";
  let baseEndpoint = `${endPoint}?api_key=${key}`;
  console.log("baseEndpoint ", baseEndpoint);
  return baseEndpoint;
};

export { ReturnSampleEndPoint };
