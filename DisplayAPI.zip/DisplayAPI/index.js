import React, { useEffect, useState, useReducer } from "react";
import axios from "axios";
import { Table } from "antd";
import moment from "moment";
import { BiBitcoin } from "react-icons/bi";
import { ReturnSampleEndPoint } from "./Utility.js";
import "./apidatastyle.css";
const DisplayAPI = () => {
  const [result, setResult] = useState(); //setInfoMessage
  const [infoMessage, setInfoMessage] = useState();
  const columns = [
    {
      title: "Account",
      dataIndex: "account",
      render: (_account) => <span className="productname">{_account}</span>,
      hidden: false,
    },
    {
      title: "Account Balance",
      dataIndex: "balance",
      render: (balance) => (
        <div>
          <span className="productname">
            <BiBitcoin name="btc" style={{ color: "blue" }} size={14} />
            &nbsp;
            {balance}{" "}
          </span>
        </div>
      ),
      hidden: false,
    },
    {
      title: "Creation Time",
      dataIndex: "creationTime",
      render: (text) => <span className="productname">{text}</span>,
      hidden: false,
    },
    {
      title: "Height",
      dataIndex: "creationHeight",
      hidden: false,
    },
  ];

  //account, balance, creationTime, creationHeight

  const fetchData = async (endPoint) => {
    return await axios.get(endPoint);
  };
  const handleFetchResponse = async (res, setInfoMessage) => {
    const response = await res.data;
    console.log("Sample Data ", res);

    if (typeof response === "object" && typeof response.result == "string") {
      if (response.result.includes("error")) setInfoMessage("Error");
    } else if (
      typeof response === "object" &&
      response.error != null &&
      response.errorData != null &&
      response.result.length === 0 &&
      typeof response.result == "string"
    ) {
      setInfoMessage("");
    } else {
      let customResponse = [];

      customResponse = response.data?.map((elem, idx) => {
        const responseObject = elem;
        //  console.log("responseObject ", elem);

        return {
          key: idx,
          account: responseObject?.account,
          balance: responseObject?.balance,
          creationTime: moment(responseObject?.creation_time).format(
            "MMM DD, YYYY"
          ),
          creationHeight: responseObject?.creation_height,
        }; //
      });
      console.log("customResponse ", customResponse);
      setResult(customResponse);
    }
  };
  useEffect(() => {
    //Code to add Api logic

    var baseEndpoint = ReturnSampleEndPoint();

    var apiResponse = fetchData(baseEndpoint);

    apiResponse.then((res) => {
      handleFetchResponse(res, setInfoMessage);
    });
    console.log("ItemData ", result);
  }, []);
  //
  return (
    <>
      <div className="row">
        <div className="gn-ly-header-middle"></div>
      </div>
      <div
        className="meta-body-layout"
        style={{
          margin: "auto",
          padding: "10px",
          paddingRight: "3rem",
        }}
      >
        {result && (
          <div className="table-container">
            <Table dataSource={result} columns={columns} />
          </div>
        )}
      </div>
    </>
  );
};

export default DisplayAPI;
